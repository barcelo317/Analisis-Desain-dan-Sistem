-- phpMyAdmin SQL Dump
-- version 6.0.0-dev
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.30.23
-- Generation Time: Oct 14, 2024 at 02:06 PM
-- Server version: 8.0.18
-- PHP Version: 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sisteminformasialumni`
--

-- --------------------------------------------------------

--
-- Table structure for table `Alumni`
--

CREATE TABLE `Alumni` (
  `id_alumni` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `alamat` text,
  `tahun_lulus` year(4) DEFAULT NULL,
  `status_aktif` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Alumni`
--

INSERT INTO `Alumni` (`id_alumni`, `nama`, `email`, `telepon`, `alamat`, `tahun_lulus`, `status_aktif`) VALUES
(1, 'Budi Setiawan', 'budi@example.com', '081234567890', 'Jl. Sudirman No. 1', '2015', 1),
(2, 'Siti Aisyah', 'siti@example.com', '082345678901', 'Jl. Thamrin No. 2', '2018', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Donasi`
--

CREATE TABLE `Donasi` (
  `id_donasi` int(11) NOT NULL,
  `id_alumni` int(11) DEFAULT NULL,
  `tanggal_donasi` date NOT NULL,
  `jumlah_donasi` decimal(15,2) NOT NULL,
  `status_validasi` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Donasi`
--

INSERT INTO `Donasi` (`id_donasi`, `id_alumni`, `tanggal_donasi`, `jumlah_donasi`, `status_validasi`) VALUES
(1, 1, '2024-10-01', 500000.00, 1),
(2, 2, '2024-10-05', 300000.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `SuratPermintaan`
--

CREATE TABLE `SuratPermintaan` (
  `id_surat` int(11) NOT NULL,
  `id_alumni` int(11) DEFAULT NULL,
  `tanggal_kirim` date NOT NULL,
  `status_terima` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `SuratPermintaan`
--

INSERT INTO `SuratPermintaan` (`id_surat`, `id_alumni`, `tanggal_kirim`, `status_terima`) VALUES
(1, 1, '2024-09-25', 1),
(2, 2, '2024-09-30', 0),
(3, 1, '2024-09-25', 1),
(4, 2, '2024-09-30', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Alumni`
--
ALTER TABLE `Alumni`
  ADD PRIMARY KEY (`id_alumni`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `Donasi`
--
ALTER TABLE `Donasi`
  ADD PRIMARY KEY (`id_donasi`),
  ADD KEY `id_alumni` (`id_alumni`);

--
-- Indexes for table `SuratPermintaan`
--
ALTER TABLE `SuratPermintaan`
  ADD PRIMARY KEY (`id_surat`),
  ADD KEY `id_alumni` (`id_alumni`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Alumni`
--
ALTER TABLE `Alumni`
  MODIFY `id_alumni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Donasi`
--
ALTER TABLE `Donasi`
  MODIFY `id_donasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `SuratPermintaan`
--
ALTER TABLE `SuratPermintaan`
  MODIFY `id_surat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Donasi`
--
ALTER TABLE `Donasi`
  ADD CONSTRAINT `Donasi_ibfk_1` FOREIGN KEY (`id_alumni`) REFERENCES `Alumni` (`id_alumni`) ON DELETE CASCADE;

--
-- Constraints for table `SuratPermintaan`
--
ALTER TABLE `SuratPermintaan`
  ADD CONSTRAINT `SuratPermintaan_ibfk_1` FOREIGN KEY (`id_alumni`) REFERENCES `Alumni` (`id_alumni`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
